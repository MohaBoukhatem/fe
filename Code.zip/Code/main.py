from moteur import *
from electro import *

#first rotation
moteur_func1()

